#pragma once
extern const int fire_smallNAttribsPerVertex;
extern const int fire_smallNVertices;
extern const int fire_smallNTriangles;
extern const float fire_smallVertices[];
extern const unsigned fire_smallTriangles[];

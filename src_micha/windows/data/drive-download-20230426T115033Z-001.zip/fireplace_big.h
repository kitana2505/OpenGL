#pragma once
extern const int fire_bigNAttribsPerVertex;
extern const int fire_bigNVertices;
extern const int fire_bigNTriangles;
extern const float fire_bigVertices[];
extern const unsigned fire_bigTriangles[];

#pragma once
extern const int fire_mediumNAttribsPerVertex;
extern const int fire_mediumNVertices;
extern const int fire_mediumNTriangles;
extern const float fire_mediumVertices[];
extern const unsigned fire_mediumTriangles[];

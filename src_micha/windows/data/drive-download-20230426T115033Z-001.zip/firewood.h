#pragma once
extern const int simple_stick_008NAttribsPerVertex;
extern const int simple_stick_008NVertices;
extern const int simple_stick_008NTriangles;
extern const float simple_stick_008Vertices[];
extern const unsigned simple_stick_008Triangles[];
